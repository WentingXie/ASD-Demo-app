/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package asd.demo.model.test;



/**
 *
 * @author jonny
 */
public class AddBalance {
        public double addBalance(double amount1, double amount2) {
        return Double.sum(amount1, amount2);
    }
}
